package com.ck.entities;

import java.io.Serializable;

import lombok.Data;

@Data
public class GuaragePk implements Serializable {
	protected String guarageClubRegNo;
	protected String guarageName;
}
