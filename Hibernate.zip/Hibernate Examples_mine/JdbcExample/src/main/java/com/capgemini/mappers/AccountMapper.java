package com.capgemini.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.entities.Account;

public class AccountMapper {
	
	public Account mapResultSetRecordToAccount(ResultSet rs) throws SQLException
	{
		
		Account account=new Account();
		account.setAccountNo(rs.getInt(1));
		account.setAccountHolderName(rs.getNString(2));
		account.setAccountType(rs.getNString(3));
		account.setMobileNo(rs.getNString(4));
		account.setEmailAddress(rs.getString(5));
		account.setBalance(rs.getDouble(6));
		
		return account;
		
		
	}

}
