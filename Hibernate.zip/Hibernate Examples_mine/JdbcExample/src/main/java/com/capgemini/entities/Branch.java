package com.capgemini.entities;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class Branch implements Serializable{
	
	private int branchNo;
	private String branchName;
	private String bankName;
	private String ifscCode;
	private String contactNo;
	private String location;
	/*public void setBranchNo(int branchNo) {
		this.branchNo = branchNo;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	@Override
	public String toString() {
		return "Branch [branchNo=" + branchNo + ", branchName=" + branchName + ", bankName=" + bankName + ", ifscCode="
				+ ifscCode + ", contactNo=" + contactNo + ", location=" + location + "]";
	}*/
	
	

}
