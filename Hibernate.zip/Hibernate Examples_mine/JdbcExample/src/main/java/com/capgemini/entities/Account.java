package com.capgemini.entities;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode
public class Account implements Serializable{

	private int accountNo;
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	private String accountHolderName;
	private String accountType;
	private String mobileNo;
	private String emailAddress;
	private double balance;
	/*
	 * @Override public String toString() { return "Account [accountNo=" + accountNo
	 * + ", accountHolderName=" + accountHolderName + ", accountType=" + accountType
	 * + ", mobileNo=" + mobileNo + ", emailAddress=" + emailAddress + ", balance="
	 * + balance + "]"; }
	 */
	
	
}
