package com.capgemini.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.entities.Account;
import com.capgemini.entities.Branch;

public class BranchMapper {
	
	public Branch mapResultSetRecordToBranch(ResultSet rs) throws SQLException
	{
		Branch branch=new Branch();
	    branch.setBranchNo(rs.getInt(1));
	    branch.setBranchName(rs.getNString(2));
	    branch.setBankName(rs.getNString(3));
	    branch.setIfscCode(rs.getNString(4));
	    branch.setContactNo(rs.getString(5));
	    branch.setLocation(rs.getNString(6));
		return branch;
		
		
	}

}
