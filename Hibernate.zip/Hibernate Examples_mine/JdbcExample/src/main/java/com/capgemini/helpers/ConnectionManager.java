package com.capgemini.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionManager {
	
	static Connection connection=null;
	static Properties properties=null;
	
	public static Connection getConnection()
	{
		try {
			
			properties=new Properties();
			properties.load(ConnectionManager.class.getClassLoader().getResourceAsStream("DB.properties"));
			Class.forName(properties.getProperty("db.driverClassName"));
			connection =DriverManager.getConnection(properties.getProperty("db.url"), properties.getProperty("db.username"), properties.getProperty("db.password"));
			connection.setAutoCommit(false);
			
		}
		catch(Exception exception)
		{
			exception.printStackTrace();
		}
		
		return connection;
	}

}
