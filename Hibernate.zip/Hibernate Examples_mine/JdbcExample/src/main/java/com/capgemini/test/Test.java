package com.capgemini.test;

import java.sql.SQLException;

import com.capgemini.accessors.BranchAccessor;
import com.capgemini.accessors.AccountAccessor;
import com.capgemini.entities.Account;
import com.capgemini.entities.Branch;
import com.capgemini.helpers.ConnectionManager;

public class Test {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		AccountAccessor accountAccessor = new AccountAccessor();
		Account account = accountAccessor.findAccount(100100);
		System.out.println(account);
		BranchAccessor branchAccessor=new BranchAccessor();
		Branch branch=branchAccessor.findAccount(123);
		System.out.println(branch);
		
		
	}
}