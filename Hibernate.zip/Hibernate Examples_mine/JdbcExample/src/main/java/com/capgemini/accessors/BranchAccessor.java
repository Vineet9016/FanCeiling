package com.capgemini.accessors;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.capgemini.entities.Branch;
import com.capgemini.helpers.ConnectionManager;
import com.capgemini.mappers.BranchMapper;

public class BranchAccessor {

	public Branch findAccount(int branchNo) throws SQLException {
		Connection connection = null;
		PreparedStatement prepstmt = null;
		ResultSet rs = null;
		BranchMapper branchMapper = new BranchMapper();
		Branch branch = null;

		try {

			connection = ConnectionManager.getConnection();
			prepstmt = connection.prepareStatement(
					"select branchno,branchname,bankname,ifsccode,contactno,location from branch where branchno=?");
			prepstmt.setInt(1, branchNo);
			rs = prepstmt.executeQuery();
			while (rs.next()) {
				branch = branchMapper.mapResultSetRecordToBranch(rs);
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		} finally {
            rs.close();
            prepstmt.close();
            connection.close();
		}

		return branch;
	}

	
	
}
