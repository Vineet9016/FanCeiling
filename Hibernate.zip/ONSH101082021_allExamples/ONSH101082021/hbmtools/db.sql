
    create table staff (
       staff_no integer not null,
        full_nm varchar(255),
        age integer,
        gender varchar(255),
        designation varchar(255),
        mobile_nbr varchar(255),
        email_address varchar(255),
        primary key (staff_no)
    ) engine=InnoDB

    create table staff (
       staff_no integer not null,
        full_nm varchar(255),
        age integer,
        gender varchar(255),
        designation varchar(255),
        experience integer,
        mobile_nbr varchar(255),
        email_address varchar(255),
        primary key (staff_no)
    ) engine=InnoDB
