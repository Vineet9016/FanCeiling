alter table staff add column experience integer
