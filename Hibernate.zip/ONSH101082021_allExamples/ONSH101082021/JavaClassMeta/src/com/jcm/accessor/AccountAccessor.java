package com.jcm.accessor;

public class AccountAccessor {
	protected String tableName;

	public String getAccountHolderName(int accountNo) {
		return "Joy";
	}

}
